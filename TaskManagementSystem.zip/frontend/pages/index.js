import Head from 'next/head';

export default function Home() {
  return (
    <div>
      <Head><title>Task Management</title></Head>
      <h1>Welcome to Task Management System</h1>
    </div>
  );
}