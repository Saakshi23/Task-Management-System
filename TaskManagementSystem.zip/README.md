# Task Management System

A full-stack task management system for teams. Features user authentication, task CRUD, dashboard, and notifications.

## Frontend

- Next.js based interface
- Pages: Home, Dashboard (To be added)

## Backend

- Express.js API
- MongoDB connection (To be added)
- JWT Authentication (To be added)

## How to run

```bash
cd backend
npm install
npm run dev

cd ../frontend
npm install
npm run dev
```